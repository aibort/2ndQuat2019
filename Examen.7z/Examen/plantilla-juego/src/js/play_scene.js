'use strict';

//No he conseguido hacer que la bola se divida, por lo que no he podido hacer partes del enunciado
//El juego se termina cuando se acaba el tiempo, o el jugador colisiona 8 veces con la bola, en vez de eliminar todas las bolas
//La bola solo tiene 1 sonido, el de colision
//La bola solo tiene 2 animaciones, moverse y colisionar

  var PlayScene = {
  create: function () {

    this.game.physics.startSystem(Phaser.Physics.ARCADE);

    //paredes
    this.paredarriba = this.game.add.sprite(0,0, 'box');
    this.paredarriba.width = 800;
    this.paredarriba.height = 20;
    this.game.physics.arcade.enable(this.paredarriba);
    this.paredarriba.body.immovable = true;

    this.paredabajo = this.game.add.sprite(0,580, 'box');
    this.paredabajo.width = 800;
    this.paredabajo.height = 20;
    this.game.physics.arcade.enable(this.paredabajo);
    this.paredabajo.body.immovable = true;

    this.paredizq = this.game.add.sprite(0,0, 'box');
    this.paredizq.width = 20;
    this.paredizq.height = 600;
    this.game.physics.arcade.enable(this.paredizq);
    this.paredizq.body.immovable = true;

    this.paredder = this.game.add.sprite(780,0, 'box');
    this.paredder.width = 20;
    this.paredder.height = 600;
    this.game.physics.arcade.enable(this.paredder);
    this.paredder.body.immovable = true;


    //bola
    this.bola = this.game.add.sprite(100,100, 'ball');
    this.bola.width = 100;
    this.bola.height = 100;
    this.game.physics.arcade.enable(this.bola);
    this.bola.body.velocity.setTo(200,-200);
    this.bola.body.bounce.set(1);
    this.bola.animations.add('move', [0,5,10], 3);
    this.bola.animhit = this.bola.animations.add('hit', [20,21,22], 3);


    //jugador
    this.player = this.game.add.sprite(200, 200, 'player');
    this.player.width = 50;
    this.player.height = 50;
    this.game.physics.arcade.enable(this.player);
    this.player.body.immovable = true;
    this.player.animations.add('quieto', [0,1,2,3], 4);
    this.player.animations.add('move', [0,4,8,12], 4);

    this.sonido = this.game.add.audio('hit');

    this.cursors = this.game.input.keyboard.createCursorKeys();
    this.space = this.game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);

    this.numcol = 8;
    this.timer = this.game.time.events.add(Phaser.Timer.SECOND * 30, this.fin, this);
    this.final = false;

  },

  update: function(){

    this.player.body.velocity.setTo(0,0);

    if (this.game.physics.arcade.collide(this.bola, this.player)){
      this.bola.animations.play('hit');
      this.sonido.play();
      if(this.numcol>0)
        this.numcol--;
      if(this.numcol == 0) {
        this.tiempo = "HAS GANADO";
        this.final = true;
      }
    } else if(!this.bola.animhit.isPlaying) this.bola.animations.play('move');
    
    this.game.physics.arcade.collide(this.bola, this.paredarriba);
    this.game.physics.arcade.collide(this.bola, this.paredabajo);
    this.game.physics.arcade.collide(this.bola, this.paredizq);
    this.game.physics.arcade.collide(this.bola, this.paredder);
    this.game.physics.arcade.collide(this.player, this.paredarriba);
    this.game.physics.arcade.collide(this.player, this.paredabajo);
    this.game.physics.arcade.collide(this.player, this.paredizq);
    this.game.physics.arcade.collide(this.player, this.paredder);

    if(this.cursors.left.isDown){
      this.player.body.velocity.x = -300;
      this.player.animations.play('move');
    }
    else if(this.cursors.right.isDown){
      this.player.body.velocity.x = 300;
      this.player.animations.play('move');
    }
    else if(this.cursors.up.isDown){
      this.player.body.velocity.y = -300;
      this.player.animations.play('move');
    }
    else if(this.cursors.down.isDown){
      this.player.body.velocity.y = 300;
      this.player.animations.play('move');
    } else this.player.animations.play('quieto');

    if(this.final == false) {
      this.tiempo = this.game.time.events.duration;
    } else {
      this.player.body.velocity.setTo(0,0);
      this.player.animations.stop();
      this.bola.animations.stop();
      this.bola.body.velocity.setTo(0,0);
      if(this.space.isDown) {
        this.game.state.start('play');
      }
    }


  },

  fin: function(){
    this.tiempo = "HAS PERDIDO";
    this.final = true;
  },

  render: function() {
    this.game.debug.text(this.tiempo, 30, 30);
    this.game.debug.text(this.numcol + ' colisiones', 30, 50);
  }

};

module.exports = PlayScene;
