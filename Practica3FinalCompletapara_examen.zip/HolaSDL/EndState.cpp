#include "EndState.h"
#include "Game.h"
#include "checkML.h"

const string EndState::s_endID = "END";

void EndState::exit(Game* game) {
	game->exitPrograma();
}

void EndState::menu(Game* game) {
	game->callMenuState();
}