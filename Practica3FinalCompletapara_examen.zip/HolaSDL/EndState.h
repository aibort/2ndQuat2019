#pragma once
#ifndef END_STATE
#define END_STATE
#include "GameState.h"
#include "MenuButton.h"
#include "checkML.h"
#include "ArkanoidObject.h"

class EndState: public GameState {
public:
	EndState(Texture* t[NUM_TEXTURES], Game* game, int puntuacion) : GameState(game) {
		if (PUNT_GANA > puntuacion) {
			objetos.push_back(new ArkanoidObject(Vector2D((WIN_WIDTH / 2) - 100, 0), t[LoseText], 200, 100, 0, 0));
		}else
			objetos.push_back(new ArkanoidObject(Vector2D(((WIN_WIDTH / 2) - 100), 0), t[WinText], 200, 100, 0, 0));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT / 5), t[MenuText], 200, 100, 0, 0, menu, this->game));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT * 2 / 5), t[ExitText], 200, 100, 0, 0, exit, this->game));
	}

	string getStateID() const { return s_endID; }

private:

	static void exit(Game* game);

	static void menu(Game* game);

	static const string s_endID;
};
#endif