#include "GameState.h"
#include "Game.h"
#include "checkML.h"

void GameState::update() {
	for (GameObject* o : objetos) {
		o->update();
	}
}

void GameState::render() {
	for (GameObject* o : objetos) {
		o->render();
	}
}

void GameState::handleEvents(SDL_Event& event){
	bool handled = false;
	it = objetos.begin();
	/*En el momento en que se ha detectado que se ha pulsado algo para un objeto, devuleve true para que no siga conmprobando con los demas
	si no se hace esto, cuando se comprueba el handle de un boton que lo que hace es eliminar un estado, al volver para comprobar el siguiente boton
	este ya no existe*/
	while (!handled && it != objetos.end()) { 
		handled = (*it)->handleEvents(event);
		if(!handled)
			++it;
	}
}


void GameState::run() {
	uint32_t startTime, frameTime;
	startTime = SDL_GetTicks();
	while (!exit) {
		frameTime = SDL_GetTicks() - startTime; // Tiempo desde �ltima actualizaci�n
		if (frameTime >= FRAME_RATE) {
			game->update(); // Actualiza el estado de todos los objetos del juego
			startTime = SDL_GetTicks();
		}
		game->render();
	}
}

GameState::~GameState() {
	for (it = objetos.begin(); it != objetos.end();)
	{
		auto next = it;
		++next;
		delete (*it);
		it = next;
	}
}