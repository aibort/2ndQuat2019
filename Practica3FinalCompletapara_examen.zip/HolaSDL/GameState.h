#pragma once
#ifndef GAME_STATE
#define GAME_STATE

#include "checkML.h" 
#include "GameObject.h"
#include <string>
#include <list>
//#include "Vector2D.h"
//#include "Texture.h"

const enum TexturesName { BallText, PaddleText, BricksText, SideText, TopsideText, RewardText, LoadText, StartText, MenuText, ExitText, BackText, WinText, LoseText };
const enum WallName { WallLeft, WallUp, WallRight };
const int WIN_WIDTH = 800;
const int WIN_HEIGHT = 600;
const int NUM_TEXTURES = 13;
const uint anchoW = 20;
const string RUTA = "..\\images\\";
const string MAPAS = "..\\mapas\\level";
const uint32_t FRAME_RATE = 5;
const uint ballAA = 18;
const uint largoP = 100;
const int NUM_MUROS = 3;
const int PROB_REWARD = 10;
const int MAX_MAPAS = 3;
const int PUNT_GANA = 1000;

typedef unsigned int uint;

using namespace std;

class Game;

class GameState {
protected:
	list<GameObject*>::iterator it;
	bool exit = false;
	uint FRAME_RATE = 5;
	list<GameObject*> objetos;
	Game* game;
public:
	GameState(Game* game) {
		this->game = game;
	}
	virtual ~GameState();
	virtual void run();
	virtual void update();
	virtual void render();
	virtual void handleEvents(SDL_Event& event);
	virtual string getStateID() const  = 0;


};
#endif