#include "GameStateMachine.h"
#include "checkML.h"

void GameStateMachine::pushState(GameState* pState) {
	states.push(pState);

}

void GameStateMachine::popState() {
	if (!states.empty()) {
		GameState* a = states.top();
		states.pop();
		delete a;
	}
}

void GameStateMachine::changeState(GameState* pState) {
	if (pState->getStateID() != states.top()->getStateID()) {
		popState();
		pushState(pState);
	}

}

GameState* GameStateMachine::currentState() {
	if (states.empty()) {
		return NULL;
	}
	else {
		return states.top();
	}
}

bool GameStateMachine::empty() {
	return states.empty();
}

void GameStateMachine::libera() {
	while (!states.empty()) {
		popState();
	}
}

GameStateMachine::~GameStateMachine() {
	while (!states.empty()) {
		GameState* a = states.top();
		states.pop();
		delete a;
	}
}