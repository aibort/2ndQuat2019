#pragma once
#include "GameState.h"
#include <stack>
#include <string>
#include "checkML.h"

//using namespace std;

class GameStateMachine {
public:
	~GameStateMachine();
	void pushState(GameState* pState);
	void changeState(GameState* pState);
	void popState();
	void libera();
	GameState* currentState();
	bool empty();
private:
	stack <GameState*> states;

};