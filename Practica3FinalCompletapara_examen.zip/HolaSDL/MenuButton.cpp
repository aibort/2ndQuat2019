#include "MenuButton.h"
#include "checkML.h"

bool MenuButton::handleEvents(SDL_Event& event) {
	if (event.type == SDL_MOUSEBUTTONUP) {
		if (event.motion.x >= pos.getX() && event.motion.x <= pos.getX() + w && event.motion.y >= pos.getY() && event.motion.y <= pos.getY() + h) {
			m_callback(game);
			return true;
		}
	}
	return false;

}