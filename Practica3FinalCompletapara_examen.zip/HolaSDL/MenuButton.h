#ifndef MenuButton_H
#define MenuButton_H
#include "SDL.h"
#include "SDL_image.h"
#include "SDLGameObject.h"
#include "checkML.h"

class Game;

class MenuButton: public SDLGameObject{
private:
	Game* game = nullptr;
	void (*m_callback) (Game* game);
public:
	//Initialize the variables
	MenuButton(Vector2D pos, Texture* t, uint w, uint h, uint fX, uint fY, void(*callback)(Game* game), Game* game) : SDLGameObject(pos, t, w, h, fX, fY), m_callback(*callback), game(game) {}

	virtual bool handleEvents(SDL_Event& event);

	//void clicked();
};
#endif