#include "MenuState.h"
#include "Game.h"
#include "checkML.h"

const string MenuState::s_menuID = "MENU";

void MenuState::play(Game* game) {
	game->callPlayState();
}

void MenuState::exit(Game* game) {
	game->exitPrograma();
}

void MenuState::load(Game* game) {
	game->loadGame();
}
