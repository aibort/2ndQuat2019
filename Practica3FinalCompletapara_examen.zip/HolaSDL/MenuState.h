#pragma once
#ifndef MenuState_H
#define MenuState_H
#include "GameState.h"
#include "MenuButton.h"
#include "checkML.h"
#include <iostream>

class MenuState : public GameState {
public:
	MenuState(Texture* t[], Game* game) : GameState(game) {
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT / 5), t[StartText], 200, 100, 0, 0, play, this->game));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT * 3 / 5), t[ExitText], 200, 100, 0, 0, exit, this->game));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT * 2 / 5), t[LoadText], 200, 100, 0, 0, load, this->game));
	}

	string getStateID() const { return s_menuID; }


private:

	static void play(Game* game);

	static void exit(Game* game);

	static void load(Game* game);

	static const string s_menuID;

	//void playstate();

	
};
#endif