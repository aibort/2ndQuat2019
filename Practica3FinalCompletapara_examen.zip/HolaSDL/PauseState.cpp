#include "PauseState.h"
#include "checkML.h"
#include "Game.h"

const string PauseState::s_playID = "PAUSE";

void PauseState::exit(Game* game) {
	game->exitPrograma();
}

void PauseState::backToGame(Game* game) {
	game->deleteTop();
}

void PauseState::handleEvents(SDL_Event& event) {
	if (event.type == SDL_KEYUP) {
		if (event.key.keysym.sym == SDLK_p) {
			game->deleteTop();
		}
	}
	GameState::handleEvents(event);
}

void PauseState::menu(Game* game) {
	game->callMenuState();
}