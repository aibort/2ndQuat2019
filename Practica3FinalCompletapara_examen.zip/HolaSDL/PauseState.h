#pragma once
#include "GameState.h"
#include "MenuButton.h"
#include "checkML.h"
#include <iostream>

class PauseState : public GameState {
public:
	PauseState(Texture* t[], Game* game) : GameState(game) {
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT *3 / 5), t[ExitText], 200, 100, 0, 0, exit, game));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT  / 5), t[BackText], 200, 100, 0, 0, backToGame, game));
		objetos.push_back(new MenuButton(Vector2D((WIN_WIDTH / 2) - 100, WIN_HEIGHT * 2 / 5), t[MenuText], 200, 100, 0, 0, menu, game));
	}

	string getStateID() const { return s_playID; }
	
	virtual void handleEvents(SDL_Event& event);

private:
	static void exit(Game* game);

	static void backToGame(Game* game);

	static void menu(Game* game);

	static const string s_playID;
};