#pragma once
#include "GameState.h"
#include <iostream>

#include "FileNotFoundError.h"
#include "checkML.h"

#include "Paddle.h"	
#include "Wall.h"
#include "BlocksMap.h"
#include "Ball.h"
#include "Reward.h"



class PlayState: public GameState {
public:
	PlayState(Texture* t[NUM_TEXTURES], Game* game);
	virtual ~PlayState();
	/*virtual void render();*/
	virtual void update();
	virtual void handleEvents(SDL_Event& event);

	void loadGame();
	void saveGame();

	//
	void resetBall();
	bool hayBolas();
	void eliminaRewards();
	void eliminaObj(std::list<GameObject*>::iterator iterator);
	void ultimoreward();
	void resetFirstReward();
	void crearReward(Vector2D pos);
	void tipoReward(int i);
	int CollDead(SDL_Rect p);
	Vector2D wallColl(SDL_Rect dimball, const Vector2D& vel);
	Vector2D collides(SDL_Rect dimball, const Vector2D& vel);
	void cargaNumMapa();
	void muestraPuntuacion(int suma);

	//

	string getStateID() const { return s_playID; }

private:
	//

	list<GameObject*> rewardElimina;

	
	std::list<GameObject*>::iterator movObj;

	int numvidas = 3;
	bool exit = false;
	bool reward = true;
	int numBolas = 0;
	int numRewards = 0;
	int numMapa = 1;
	int puntuacion = 0;

	BlockMap* mapa = nullptr;
	Texture* texturas[NUM_TEXTURES];
	static const string s_playID;

	////
	//void saveGame();
	//void loadGame(string name);

	//void resetFirstReward();
	//void ultimoreward();

	//void resetBall();
	//bool hayBolas();
	////


};