#include "SDLGameObject.h"
#include "checkML.h"

SDL_Rect SDLGameObject::getRect() {
	SDL_Rect desRect;
	desRect.x = this->pos.getX();
	desRect.y = this->pos.getY();
	desRect.w = this->w;
	desRect.h = this->h;
	return desRect;
}

void SDLGameObject::render() {
	t->renderFrame(getRect(), fY, fX);
}